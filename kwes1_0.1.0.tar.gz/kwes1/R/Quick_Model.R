quick_model = function(x,i)
{
  library(ranger)
  library(caret)
  colnames(x)[i] = "target"
  Grid = expand.grid(mtry = 2, splitrule = c("gini"), min.node.size = c(1:3))
  model = train(target~., x, method = "ranger", trControl = trainControl(method = "cv", number = 7), tuneGrid = Grid)
  return(max(model$results$Accuracy))
}
